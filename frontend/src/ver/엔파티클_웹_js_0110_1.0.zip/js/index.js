/* eslint-disable strict */
/* jshint browser: true, esversion: 6, asi: true */
/* globals uibuilder */
// @ts-nocheck

/** Minimalist code for uibuilder and Node-RED */
'use strict'

// return formatted HTML version of JSON object
var keypad = document.getElementById('node_keypad');
var nodetable = document.getElementById('node_table');
var time = new Date().getTime();
window.syntaxHighlight = function (json) {
    json = JSON.stringify(json, undefined, 4)
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    json = json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number'
        if ((/^"/).test(match)) {
            if ((/:$/).test(match)) {
                cls = 'key'
            } else {
                cls = 'string'
            }
        } else if ((/true|false/).test(match)) {
            cls = 'boolean'
        } else if ((/null/).test(match)) {
            cls = 'null'
        }
        return '<span class="' + cls + '">' + match + '</span>'
    })
    return json
} // --- End of syntaxHighlight --- //

// Send a message back to Node-RED
window.fnSendToNR = function fnSendToNR(topic, payload) {
    uibuilder.send({
        'topic': topic,
        'payload': payload,
    })
}

// run this function when the document is loaded
window.onload = function () {

    // Start up uibuilder - see the docs for the optional parameters
    uibuilder.start()
    // uibuilder.send({
    //     'topic': "test",
    //     'payload': "test2",
    // })
    // Listen for incoming messages from Node-RED
    uibuilder.onChange('msg', function (msg) {
        console.info('[indexjs:uibuilder.onChange] msg received from Node-RED server:', msg)
        // dump the msg as text to the "msg" html element
        const Rtank1 = document.getElementById('R_tank1');
        const Rtank2 = document.getElementById('R_tank2');
        const Rtank3 = document.getElementById('R_tank3');
        const Stank1 = document.getElementById('S_Tank1');
        const leftlock = document.getElementById('left_lock');
        const rightlock = document.getElementById('right_lock');
        const sentank1 = document.getElementById('sensingtank1');
        const sentank2 = document.getElementById('sensingtank2');
        const sentank3 = document.getElementById('sensingtank3');
        const sentime= document.getElementById('sensingtime');
        if(msg["topic"] == "r_tank1"){
            Rtank1.innerHTML = msg["payload"]; 
        }else if(msg["topic"] == "r_tank2"){
            Rtank2.innerHTML = msg["payload"]; 
        }else if(msg["topic"] == "r_tank3"){
            Rtank3.innerHTML = msg["payload"]; 
        }else if(msg["topic"] == "stank1"){
            Stank1.innerHTML =msg["payload"]; 
        }else if(msg["topic"] == "left" && msg["payload"] == 'open'){
            leftlock.style.display= 'none';
        }else if(msg["topic"] == "right" && msg["payload"] == 'open'){
            rightlock.style.display= 'none';
        }else if(msg["topic"] == "sensingtank1"){
            sentank1.innerText = msg["payload"]
        }else if(msg["topic"] == "sensingtank2"){
            sentank2.innerText = msg["payload"]
        }
        else if(msg["topic"] == "sensingtank3"){
            sentank3.innerText = msg["payload"]
        }
        else if(msg["topic"] == "sensingtime"){
            sentime.innerText = msg["payload"]
        }


    })
}

function is_check() {
    const checkbox = document.getElementById('check_box');
    const is_checked = checkbox.checked;
    if(is_checked == true){
        document.getElementById('pro_li_2').className ='active ing';
        document.getElementById('pro_li_1').className ='';
    }else{
        document.getElementById('pro_li_2').className ='';
        document.getElementById('pro_li_1').className ='active ing';
    }
}

function moduleon(num){
    if(num == 1){
        document.getElementById("modstate").innerHTML = "Open";
        uibuilder.send({
            'topic': "module",
            'payload': "open",
        })
    }else if(num == 2){
        document.getElementById("modstate").innerHTML = "Close";
        uibuilder.send({
            'topic': "module",
            'payload': "close",
        })
    }
}


function moduleon(num){
    if(num == 1){
        document.getElementById("modstate").innerHTML = "Open";
        uibuilder.send({
            'topic': "module",
            'payload': "open",
        })
    }else if(num == 2){
        document.getElementById("modstate").innerHTML = "Close";
        uibuilder.send({
            'topic': "module",
            'payload': "close",
        })
    }
}

function sensoron(num){
    if(num == 1){
        document.getElementById("senstate").innerHTML = "Open";
        uibuilder.send({
            'topic': "sensor",
            'payload': "open",
        })
    }else if(num == 2){
        document.getElementById("senstate").innerHTML = "Close";
        uibuilder.send({
            'topic': "sensor",
            'payload': "close",
        })
    }
}

function valveon(num){
    if(num == 1){
        document.getElementById("valstate").innerHTML = "Open";
        uibuilder.send({
            'topic': "valve",
            'payload': "open",
        })
    }else if(num == 2){
        document.getElementById("valstate").innerHTML = "Close";
        uibuilder.send({
            'topic': "valve",
            'payload': "close",
        })
    }
}

function tank(num){
    var inputString = prompt('용량을 입력하세요.','ex) 120');
    var stank1 = document.getElementById('S_Tank1');
    var stank2 = document.getElementById('S_Tank2');
    var stank3 = document.getElementById('S_Tank3');
  
    if(num == 1){
        stank1.innerText = inputString;
        uibuilder.send({
            'topic': "tank1",
            'payload': inputString,
        })
    }else if(num == 2){
        stank2.innerText = inputString;
        uibuilder.send({
            'topic': "tank2",
            'payload': inputString,
        })
    }else if(num == 3){
        stank3.innerText = inputString;
        uibuilder.send({
            'topic': "tank3",
            'payload': inputString,
        })
    }
}
 
function stime(){
    var inputString = prompt('시간을 입력하세요.','ex) 120');
    var stime = document.getElementById('S_time');
    stime.innerText = inputString;
    uibuilder.send({
        'topic': "time",
        'payload': inputString,
    })
}