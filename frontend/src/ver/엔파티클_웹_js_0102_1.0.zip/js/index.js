/* eslint-disable strict */
/* jshint browser: true, esversion: 6, asi: true */
/* globals uibuilder */
// @ts-nocheck

/** Minimalist code for uibuilder and Node-RED */
'use strict'

// return formatted HTML version of JSON object
var keypad = document.getElementById('node_keypad');
var nodetable = document.getElementById('node_table');
var time = new Date().getTime();
window.syntaxHighlight = function (json) {
    json = JSON.stringify(json, undefined, 4)
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    json = json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number'
        if ((/^"/).test(match)) {
            if ((/:$/).test(match)) {
                cls = 'key'
            } else {
                cls = 'string'
            }
        } else if ((/true|false/).test(match)) {
            cls = 'boolean'
        } else if ((/null/).test(match)) {
            cls = 'null'
        }
        return '<span class="' + cls + '">' + match + '</span>'
    })
    return json
} // --- End of syntaxHighlight --- //

// Send a message back to Node-RED
window.fnSendToNR = function fnSendToNR(topic, payload) {
    uibuilder.send({
        'topic': topic,
        'payload': payload,
    })
}

// run this function when the document is loaded
window.onload = function () {

    // Start up uibuilder - see the docs for the optional parameters
    uibuilder.start()
    // uibuilder.send({
    //     'topic': "test",
    //     'payload': "test2",
    // })
    // Listen for incoming messages from Node-RED
    uibuilder.onChange('msg', function (msg) {
        console.info('[indexjs:uibuilder.onChange] msg received from Node-RED server:', msg)
        // dump the msg as text to the "msg" html element
        const Rtank1 = document.getElementById('R_tank1');
        const Rtank2 = document.getElementById('R_tank2');
        const Rtank3 = document.getElementById('R_tank3');
        const Stank1 = document.getElementById('S_Tank1');
        const sd = document.getElementById('sd');
        if(msg["topic"] == "r_tank1"){
            Rtank1.innerHTML = msg["topic"] +msg["payload"]; 
        }else if(msg["topic"] == "r_tank2"){
            Rtank2.innerHTML = msg["topic"] +msg["payload"]; 
        }else if(msg["topic"] == "r_tank3"){
            Rtank3.innerHTML = msg["topic"] +msg["payload"]; 
        }else if(msg["topic"] == "stank1"){
            Stank1.innerHTML =msg["payload"]; 
        }else if(msg["topic"] == "make"){
            // var db2 = msg["payload"].split(":")
           // var db = msg["payload"].split(unescape(''))
            // var db2 = JSON.parse(db[0]);
           // var db3 = db2[0]
            console.log(Object.keys(msg["payload"]["result"]).length)
            for(var i=0; i<Object.keys(msg["payload"]["result"]).length; i++)
            if(i == 9){
                sd.innerHTML += ''
            }else{
            sd.innerHTML += msg["payload"]["result"][i]["name"] + '  '
            sd.innerHTML += msg["payload"]["result"][i]["password"] + '<br>'
            }
        }

    })
}

function is_check() {
    const checkbox = document.getElementById('check_box');
    const is_checked = checkbox.checked;
    if(is_checked == true){
        document.getElementById('pro_li_2').className ='active ing';
        document.getElementById('pro_li_1').className ='';
    }else{
        document.getElementById('pro_li_2').className ='';
        document.getElementById('pro_li_1').className ='active ing';
    }
}


